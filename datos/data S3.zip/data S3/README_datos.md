# Procedencia de los datos — Sesión 3

## Datos REALES

### `equities_reales_diario.parquet`
9 tickers, uno por sector, de tu carpeta `Trading Labs/data/ohlcv`. Velas de 5
minutos filtradas a sesión regular (09:30–15:55) y resampleadas a diario.

> **Lo importante de este archivo en S3 es lo que NO tiene:** no hay
> `adj_close`, no hay dividendos, no hay `split_ratio`. Ésa es la situación
> normal con datos gratuitos, y es el punto de partida del bloque 2.

Se verificó que en esta ventana **no hay splits detectables** por su ratio
(2:1, 3:1, 4:1, 3:2). Eso no prueba que la serie esté ajustada — prueba que sin
metadatos de corporate actions no se puede saber.

### `ms_5min_real.parquet`
Morgan Stanley en velas de 5 minutos, desde 2023, sesión regular, volumen > 0.
62.763 barras.

**Para qué:** construir barras de dólar sobre dato real y comparar su curtosis
contra las barras de tiempo (bloque 4).

## Gemelos SIMULADOS (con verdad conocida)

Generados con `curso_data.py`. La verdad está en `verdad_gemelos.json`.

### `equities_gemelo_con_acciones.parquet`
Una acción con **28 dividendos y 1 split 2:1** (2020-02-25), con `close`,
`adj_close`, `dividend` y `split_ratio`.

**Para qué:** es el único lugar donde se puede **verificar** que la
reconstrucción del `adj_close` quedó bien. La solución del ejercicio 3.1
alcanza un error máximo de **2.8e-14** — exacto hasta precisión de máquina.

Ese día el `close` crudo cae **−50.0%** y el ajustado **−0.05%**. Es el ejemplo
más limpio del curso de un evento que el modelo aprendería y que nunca ocurrió.

### `futuros_gemelo.parquet`
20 contratos con `date`, `contract`, `close`, `expiry`, `days_to_exp`,
`is_active`. 2.415 filas, 19 rolls.

**Para qué:** construir las tres series de empalme (concatenada,
back-adjusted, ratio-adjusted) y comprobar que dan **tres retornos acumulados
distintos** sobre el mismo activo (+244.8%, +143.8%, +180.0%).

> No hay futuros reales en la carpeta de OHLCV. El símbolo `ES` que aparece
> ahí es **Eversource Energy** (utility), no el E-mini del S&P.

## Nota metodológica

En esta sesión el gemelo no está para "reemplazar" al dato real. Está porque
**no se puede aprender a corregir un sesgo sin poder verificar la corrección**,
y ninguna fuente gratuita entrega la verdad contra la cual verificar.
