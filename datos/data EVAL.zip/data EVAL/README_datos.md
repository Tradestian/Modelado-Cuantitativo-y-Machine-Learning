# Datos de la evaluación · Módulo 2, sesiones 1 a 8

Doce archivos, 9.6 MB. Son **los mismos datos de las ocho sesiones**,
consolidados en una sola carpeta para que la evaluación sea autónoma.

No hay ningún archivo nuevo: todo lo que hay aquí ya lo usaste en clase.

---

## Dato real de mercado ✅

| Archivo | Qué es | Procede de |
|---|---|---|
| `ibkr_diario.parquet` | **33 acciones, 7 sectores, 10 años** (2016-10-17 → 2026-10-14), 82.895 filas. OHLCV diario ajustado por splits, solo sesión regular | Interactive Brokers · S7-S8 |
| `ibkr_intradia_5min.parquet` | 5 acciones (AAPL, JPM, MCD, NEE, XOM), 1 año de barras de 5 minutos, 97.530 filas | Interactive Brokers · S8 |
| `equities_reales_diario.parquet` | 9 acciones, una por sector (AMD, AMT, BHP, DTE, FLR, GILT, MCD, MS, SLB), 2020-2026, con `dollar_volume` ya calculado | Tu histórico de 5 min, resampleado · S1-S6 |
| `ms_5min_real.parquet` | Morgan Stanley, barras de 5 minutos, 2023-01 → 2026-03, 62.763 filas | Tu histórico · S3 |
| `order_book_real_xbtusd.parquet` | **Libro de órdenes de 20 niveles por lado**, BTC/USD. Columnas: `lado`, `nivel`, `precio`, `tamano_btc` | Kraken, API pública, capturado el 25-ago-2026 · S1 |
| `trades_reales_btcusd.parquet` | 300 operaciones tick por tick con lado (`side`), precio, tamaño | Coinbase Exchange, API pública, 21-ago-2026 · S1 |
| `ticker_real_btcusd.parquet` | Una foto de bid/ask/last y volumen de 24 h | Kraken · S1 |

## Gemelos simulados 🧪

Existen porque hay preguntas que **no se pueden contestar con dato real**: las
que requieren conocer la verdad para comprobar si un estimador la recupera.

| Archivo | Verdad que contiene | Para qué |
|---|---|---|
| `equities_gemelo_simulado.parquet` | 10 tickers en 3 tiers de liquidez, con la columna **`spread_verdadero_bps`** | Verificar Roll y Corwin-Schultz contra la verdad |
| `trades_gemelo_simulado.parquet` | 20.000 trades de un día, generados con un spread conocido | Convergencia del estimador de Roll |
| `equities_gemelo_con_acciones.parquet` | Un ticker con **dividendos y un split**, con `adj_close`, `dividend` y `split_ratio` | Reconstruir el ajuste y medir el daño de no hacerlo |
| `futuros_gemelo.parquet` | Contratos con vencimiento y `days_to_exp` | Los tres métodos de empalme |
| `par_gemelo_cointegrado.parquet` | Dos series A y B cointegradas con θ y β conocidos | Estimar half-life y comprobar el estimador |

> ⚠️ **Sobre `spread_verdadero_bps`:** la columna está ahí a propósito, pero
> **las preguntas te piden estimar primero y comparar después**. Si mirás la
> verdad antes de estimar, el ejercicio no mide nada y se nota en la respuesta.

---

## Cómo se carga

El notebook de la evaluación lo hace solo. Si trabajás en Colab, la primera
celda descarga `data EVAL.zip` del repositorio del curso.

En local, la carpeta tiene que estar junto al notebook:

```
EVAL_M2_fases_1a8/
├── EVALUACION_M2.ipynb
└── data EVAL/
    ├── ibkr_diario.parquet
    └── ...
```

---

## Lo que NO hay aquí, y es a propósito

| No está | Por qué |
|---|---|
| Datos fundamentales | El curso no los cubrió; no hay pregunta que los necesite |
| Más historia intradía | IBKR no entrega más de ~1 año de barras de 5 minutos |
| Un universo más grande | 33 nombres es lo que hay. Varias preguntas te piden razonar sobre qué cambiaría con 500 |
| La "respuesta correcta" en ningún archivo | Obviamente |

---

## Advertencia sobre un valor ausente

`ibkr_diario.parquet` tiene **exactamente un nulo**: el cierre de AVGO del
2018-04-05. Uno sobre 82.896 celdas.

No lo hemos arreglado. Es parte de la evaluación darse cuenta — en la sesión 12
ese mismo hueco produjo 32 pares con p-valor exactamente 0.0 en un test de
cointegración, y habrían pasado cualquier corrección por multiple testing.

**La primera parte de la evaluación es peritar los datos. Esto cuenta.**
