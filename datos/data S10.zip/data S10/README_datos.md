# Datos de la sesión 10

## `ibkr_diario.parquet`

**El mismo archivo de S7, S8 y S9.** ✅ Dato real de Interactive Brokers. Ver
`S7_features/data S7/README_datos.md` para el detalle de procedencia.

| | |
|---|---|
| Filas | 82.895 · 33 símbolos · 7 sectores |
| Rango | 2016-10-17 → 2026-10-14 (2.512 días) |
| Frecuencia | Barras diarias, `useRTH=True` |

## ⚠️ Esta sesión usa el `open` por primera vez en el curso

Hasta S9 solo usábamos el **cierre**. El motor event-driven ejecuta las órdenes
al **open de la barra siguiente**, así que la columna `open` pasa a ser
crítica — es el precio al que se llenan los fills.

Eso hace que la calidad del `open` importe. Dos cosas a favor del dato de IBKR
aquí:

- **`useRTH=True`**: el `open` es el de la apertura de la sesión regular
  (09:30 ET), no el de la primera operación del horario extendido. Si fuera lo
  segundo, estaríamos ejecutando a precios de un mercado mucho menos líquido.
- **Ajuste consistente**: IBKR ajusta todo el OHLC por splits con el mismo
  factor, así que `open` y `close` son comparables entre sí. Mezclar un `open`
  crudo con un `close` ajustado produciría gaps ficticios enormes en los días
  de split.

## Columnas derivadas que el notebook construye

El modelo de impacto de mercado del bloque 5 necesita dos columnas que no
vienen en el parquet y se calculan al cargarlo:

| Columna | Cómo se calcula | Para qué |
|---|---|---|
| `dolar_volumen` | `close × volume` | el $V$ de la ley de raíz cuadrada |
| `sigma` | desviación estándar rodante de 20 días de los log-retornos | el $\sigma$ de la misma fórmula |

## Para qué se usa el dato en cada bloque

| Bloque | Qué hace |
|---|---|
| 2 · el motor | Un backtest event-driven completo: 18.599 fills, $1.141M de volumen operado |
| 3 · la escalera | 5 configuraciones, del vectorizado al motor completo |
| 4 · fallos silenciosos | 6 corridas más (orden de ejecución, colchón de efectivo) |
| 5 · capacidad | 10 corridas: 5 capitales × con/sin impacto |

> **El notebook tarda ~35 segundos** porque corre 15 backtests event-driven
> sobre 2.512 barras. Es lento a propósito: la sesión 11 muestra que `vectorbt`
> hace lo mismo en milisegundos, y para qué sirve esa diferencia.

## Reproducirlo

```bash
python descargar_ibkr.py --que diario
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
