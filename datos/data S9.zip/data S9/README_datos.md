# Datos de la sesión 9

## `ibkr_diario.parquet`

**El mismo archivo de S7 y S8.** ✅ Dato real de Interactive Brokers. Ver
`S7_features/data S7/README_datos.md` para el detalle completo de procedencia y
verificación.

| | |
|---|---|
| Filas | 82.895 · 33 símbolos · 7 sectores |
| Rango | 2016-10-17 → 2026-10-14 (2.512 días) |
| Frecuencia | Barras diarias, `useRTH=True`, ajustadas por splits |

## Para qué se usa aquí

| Bloque | Qué hace con el dato |
|---|---|
| 2 · métricas de evaluación | Construye 4 estrategias reales y calcula 10 métricas sobre cada una |
| 3 · patologías del Sharpe | Autocorrelación observada, PSR con skew y curtosis reales |
| 4 · métricas de diseño | Turnover, break-even y concentración de 3 variantes long-short |
| 5 · la auditoría | 59 backtests de momentum con y sin cada error |

## Por qué esta sesión se repite el dataset

Las sesiones 7, 8 y 9 comparten el panel a propósito: así los resultados son
**comparables entre sesiones**. Dos ejemplos de lo que eso permite:

- Las dos features que en S7 dieron t = 0.71 y t = 0.53 de information
  coefficient son las mismas que en S9 dan Sharpe +0.125 y −0.212. **Dos
  mediciones independientes, el mismo veredicto.**
- El vol targeting de S8 reaparece en S9 como caso de estudio de métricas, con
  sus mismos números (Sharpe 0.93, máx DD −20.7%, curtosis 2.6).

Cada carpeta lleva su propia copia de todas formas, para que la sesión sea
autónoma.

## Reproducirlo

```bash
python descargar_ibkr.py --que diario
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
