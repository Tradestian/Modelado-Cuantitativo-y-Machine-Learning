# Datos de la sesión 7

## `ibkr_diario.parquet`

| | |
|---|---|
| **Origen** | Interactive Brokers, API de datos históricos vía IB Gateway |
| **Tipo** | ✅ **Dato real de mercado.** No hay nada simulado en esta sesión. |
| **Filas** | 82.895 |
| **Símbolos** | 33 acciones estadounidenses |
| **Sectores** | 7 (Tecnología, Financiero, Salud, Consumo, Energía, Industrial, Utilities) |
| **Rango** | 2016-10-17 → 2026-10-14 (10 años, 2.512 días de trading) |
| **Frecuencia** | Barras diarias |

### Columnas

| Columna | Qué es |
|---|---|
| `date` | Fecha de la barra |
| `open`, `high`, `low`, `close` | OHLC, ya **ajustado por splits** por IBKR |
| `volume` | Volumen en acciones |
| `average` | Precio promedio ponderado por volumen de la barra |
| `barCount` | Número de ticks agregados en la barra |
| `symbol` | Ticker |
| `sector` | Sector asignado en la descarga |

### Decisiones de la descarga que importan

- **`useRTH=True`** — solo sesión regular (09:30–16:00 ET). En la sesión 1
  descubrimos que mezclar horario extendido infla el volumen en dólares hasta
  2× y ensancha los rangos high-low, rompiendo Corwin-Schultz. Aquí no puede
  pasar.
- **Una sola serie de precios.** IBKR entrega el OHLC ya ajustado de forma
  consistente, así que no hay riesgo de mezclar `high`/`low` crudos con
  `adj_close` — el bug que apareció en el notebook de estudio al calcular ATR.
- **Pacing de 11 segundos entre peticiones**, para no gatillar el rate limit
  de IBKR.

### Verificación hecha sobre el archivo

| Chequeo | Resultado |
|---|---|
| Nulos | 0 |
| Duplicados `(symbol, date)` | 0 |
| Violaciones de OHLC (`high < low`, close fuera de rango) | 0 |
| Símbolos que empiezan en la misma fecha | 33 de 33 |
| Días con el panel completo | 2.511 de 2.512 |
| Saltos > 25% | 4 (COP, EOG, NVDA, SLB) — **eventos reales, no splits sin ajustar** |

### Qué faltó

`GE` y `SO` fallaron por timeout durante la descarga. El universo quedó en
33 de los 35 nombres planeados, con Industrial y Utilities en 4 en vez de 5.
No afecta a ninguna demo de la sesión.

### Reproducirlo

El script de descarga está en la raíz del curso:

```bash
python descargar_ibkr.py --que diario
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
