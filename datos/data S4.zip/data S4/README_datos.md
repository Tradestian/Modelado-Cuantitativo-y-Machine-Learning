# Procedencia de los datos — Sesión 4

En esta sesión el dato simulado **cambia de rol**. En S2 y S3 servía para
verificar estimadores. Aquí es el **grupo de control del experimento**: un
mundo donde, por construcción, no hay nada que descubrir.

## Datos REALES

### `equities_reales_diario.parquet`
Los mismos 9 tickers por sector, sesión regular, resampleados a diario.

**Dos usos en S4:**

1. **Bloque 1** — comparar los retornos reales de MS contra un GBM con la misma
   volatilidad, para ver dónde falla el modelo. Resultado verificado:
   curtosis 11.85 real vs 0.03 del GBM, y ACF(1) de |r| de 0.325 real vs
   −0.035 simulado. El GBM no produce agrupamiento de volatilidad.

2. **Bloque 5 — la trampa.** Se buscan pares cointegrados entre las 9 acciones.
   El mejor es **AMT-MS con p = 0.0037**, que se ve excelente... hasta que se
   corrige por los 36 pares probados: Bonferroni lo lleva a **0.134**, ya no
   significativo. Y solo hay **119 días** de historia solapada, porque dos de
   los nueve tickers tienen apenas un año en la carpeta.

## Gemelo SIMULADO (verdad conocida)

### `par_gemelo_cointegrado.parquet`
Dos series cointegradas cuyo spread es un proceso de Ornstein-Uhlenbeck con
parámetros elegidos por nosotros:

| Parámetro | Valor verdadero |
|---|---|
| `true_theta` | 0.14 |
| `true_half_life` | 4.95 días |
| `true_beta_hedge` | 1.4 |
| `true_sigma` | 0.012 |

**Para qué:** el ejercicio 4.2 recupera los tres parámetros con **menos de 1%
de error** (β = 1.4034, θ = 0.1388, half-life = 4.99 días).

> ⚠️ **La trampa incorporada:** la relación de cointegración de este par está
> en **logaritmos**. Si se regresan los niveles, sale β = 2.074 y half-life de
> 8.14 días — un error del 64% que **no genera ninguna advertencia en
> pantalla**. La serie sigue pareciendo estacionaria y el resultado sigue
> pareciendo razonable.

## Ruido puro (generado en vivo, sin archivo)

El bloque 4 genera estrategias de **edge exactamente cero** dentro del propio
notebook. No hay archivo porque el punto es que se genere delante de la clase.

Dos resultados verificados que conviene conocer antes de dictar:

- **Distribución nula del Sharpe:** con 1 año de datos, el **16.1%** de las
  estrategias sin ninguna señal superan Sharpe 1.0. Con 5 años, el 1.2%. Con
  10 años, prácticamente ninguna. La sd empírica coincide con $1/\sqrt{T}$
  hasta el tercer decimal.

- **Costo de buscar:** con 200 estrategias sin señal sobre 5 años, la fórmula
  $SE\sqrt{2\ln N}$ predice un máximo de **1.46** y el experimento da **1.47**.

Ese match casi exacto es el momento más fuerte de la sesión.
