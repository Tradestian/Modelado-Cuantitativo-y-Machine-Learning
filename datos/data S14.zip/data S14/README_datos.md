# Datos de la sesión 14

Dos archivos. Uno ya conocido, uno nuevo.

## `ibkr_diario.parquet` ✅ real

El mismo de S7 a S13. 33 acciones, 10 años, OHLCV diario ajustado por splits.

> ⚠️ **"Ajustado por splits" es el detalle que importa en esta sesión.** El
> precio está en unidades de hoy. Si lo dividís por un EPS publicado antes de
> un split, estás mezclando unidades — y eso infla el factor exactamente en
> los nombres que se partieron, que suelen ser los que más subieron.

## `fundamentales_pit.parquet` ✅ real · **nuevo**

| | |
|---|---|
| **Origen** | SEC EDGAR, API `companyconcept` de `data.sec.gov` |
| **Filas** | 84.453 en total · **48.776 con `tag_principal`**, que son las que usa el notebook |
| **Símbolos** | 33 (los mismos del panel de precios) |
| **Conceptos** | 8: EPS diluido, ingresos, utilidad neta, utilidad operativa, patrimonio, activos, pasivos, caja |
| **Publicaciones** | 2009-05-07 → 2026-11-06 |

### Por qué este archivo vale lo que vale

Cada fila trae **`publicado`**: la fecha en que esa cifra se hizo pública. Y
el mismo período fiscal aparece tantas veces como se haya reportado.

Eso permite reconstruir **qué sabía un inversor en cada fecha**, que es lo
único que un backtest puede usar legítimamente.

| Columna | Qué es |
|---|---|
| `simbolo`, `concepto` | identificación |
| `inicio_periodo`, `fin_periodo` | el período que cubre la cifra |
| `valor` | la cifra |
| **`publicado`** | **cuándo se hizo pública** ← la columna clave |
| `formulario` | 10-K, 10-Q, 10-K/A, 8-K |
| `tag` | la etiqueta XBRL de la que salió |
| `tag_principal` | `False` si vino de un tag alternativo |

### 🔴 `tag_principal` no es opcional: filtralo siempre

Un concepto contable llega en **varios tags de XBRL**, y son magnitudes
distintas. `caja` viene en cuatro:

| Tag | Quién lo usa |
|---|---|
| `CashAndCashEquivalentsAtCarryingValue` | casi todas ← **el canónico** |
| `CashAndDueFromBanks` | los bancos: incluye saldos en otros bancos |
| `CashCashEquivalentsRestrictedCash...` | incluye caja restringida |
| `Cash` | SLB, en parte de su historia |

Lo mismo con `utilidad_neta` (3 tags: `NetIncomeLoss`, `ProfitLoss` —que suma
minoritarios— y el disponible para accionistas comunes), `patrimonio` (2),
`ingresos` (4) y `utilidad_operativa` (2).

> **Mezclarlos no da error: da un factor silenciosamente mal.** Por eso el
> notebook arranca con `FUND = FUND[FUND["tag_principal"]]`, y por eso el
> ejercicio 4 —que necesita los alternativos— te obliga a leer el parquet
> completo a propósito y decidir.

Dato de calibración: contando re-expresiones **con** el tag en las claves da
~7% de períodos revisados; **sin** el tag da 38%, porque toma dos tags del
mismo trimestre como si fueran una revisión. El 7% es la cifra real.

### ⚠️ Los tags alternativos

Un mismo concepto se etiqueta distinto según la empresa y la época:

| Concepto | Tag alternativo | Por qué | Símbolos |
|---|---|---|---|
| ingresos | `RevenueFromContractWithCustomer…` | ASC 606 (2018) cambió la etiqueta | 27 |
| ingresos | `RevenuesNetOfInterestExpense` | **bancos** | 3 |
| pasivos | `LiabilitiesAndStockholdersEquity` | hay que restarle el patrimonio | 33 |
| utilidad operativa | `IncomeLossFromContinuingOperations…` | los bancos no reportan EBIT | 30 |

> 🔴 **El de los bancos no es comparable.** `RevenuesNetOfInterestExpense` es
> ingreso neto de intereses; las ventas de una industrial son brutas. Un
> factor cross-seccional que mezcla los dos está mal construido. El notebook
> lo dice y el ejercicio 4 lo trabaja.

### Lo que el notebook encuentra en este archivo

| Hallazgo | Número |
|---|---|
| Períodos fiscales anuales | 614 |
| Períodos re-expresados | 63 (10%) |
| …de los cuales **splits** | 26 |
| …de los cuales **re-expresiones contables** | 37 |
| Retraso mediano de publicación, 10-Q | 34 días |
| Retraso mediano, 10-K | 58 días |

Y los dos casos que estructuran la sesión:

- **NVDA FY2024**: 11.93 → 1.19. Split 10:1 de junio de 2024. **Cambio de
  unidades.**
- **AMD FY2017**: +0.04 → −0.03. Corrección contable publicada en 2019.
  **Información nueva.**

## ⚠️ El CIK de XOM

El archivo oficial `company_tickers.json` mapea cada ticker al registrante
**vigente**. Para XOM apuntaba a una entidad con datos solo desde 2025. El
CIK histórico de Exxon Mobil Corporation es **0000034088**, y está corregido
a mano en el script.

**AVGO tiene el mismo fenómeno** —Broadcom se reincorporó en Delaware en
2018— y ahí **no** lo corregimos: la entrada tardía de un activo al panel es
material de clase, no un problema a tapar.

## Reproducirlo

```bash
python descargar_sec_edgar.py     # ~1 min, 429 peticiones
python descargar_ibkr.py --que diario
```

El script de la SEC no necesita API key, pero **sí exige un correo real** en
el User-Agent: la SEC bloquea si no está.
