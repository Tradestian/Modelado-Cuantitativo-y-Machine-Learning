# Datos de la sesión 16

**Los mismos dos archivos de S14 y S15**, y esta vez el motivo es el
argumento central de la clase: el análisis de sensibilidad solo tiene sentido
si lo único que cambia es la decisión que estás probando. Cambiar también los
datos haría inatribuible cualquier diferencia.

| Archivo | Qué es |
|---|---|
| `ibkr_diario.parquet` | 33 acciones × 10 años, OHLCV diario ajustado |
| `fundamentales_pit.parquet` | 48.776 observaciones de SEC EDGAR (tag canónico) con fecha de publicación |

Ver `S14_factor_timing_I/data S14/README_datos.md` para procedencia completa,
tags alternativos, el caso del CIK de XOM y la regla split/re-expresión.

## Lo que el notebook reconstruye

S16 **reconstruye la estrategia de S15 de punta a punta** —`panel_pit()`,
los tres factores, la cartera long-short— y verifica que da el mismo
Sharpe 1.019 antes de empezar a moverle cosas. Si esa reconstrucción no
reprodujera el número de S15, el resto de la sesión no significaría nada.

## Los números que produce

### Sensibilidad (línea base: Sharpe +1.019, SE 0.317)

| Decisión movida | Sharpe | \|Δ\| / SE |
|---|---|---|
| corte 10% / 30% / 50% | 0.914 / 1.007 / 1.158 | 0.33 / 0.04 / 0.44 |
| rebalanceo diario / semanal / 63d | 0.940 / 0.935 / 0.804 | 0.25 / 0.27 / 0.68 |
| costo 0 / 20 / 50 bps | 1.043 / 0.947 / 0.801 | 0.08 / 0.23 / **0.69** |
| quitar ROE / caja / volatilidad | 0.877 / 0.911 / 0.822 | 0.45 / 0.34 / 0.62 |
| quitar 8 nombres al azar (×10) | 0.975 (rango 0.782–1.094) | 0.14 |
| quitar el año 2020 / 2022 / 2024 | 0.954 / 1.195 / 1.012 | 0.21 / 0.56 / 0.02 |

| | |
|---|---|
| decisiones probadas | 16 |
| **que mueven el Sharpe más de 1 SE** | **0** |
| cambio máximo | 0.218 (costo 50 bps) |

### Degradación

| Resultado | Valor |
|---|---|
| Sharpe rodante 2 años | rango +0.18 a +2.08 · 2018 **+1.42** → 2026 **+0.51** |
| tendencia | −0.083 de Sharpe por año |
| máximo drawdown | −19.3% |
| stop ≤ −10% | dispara 2018-10-24 · Sharpe hasta ahí **1.69**, desde ahí **+0.85** |
| stop ≤ −20% / −25% | nunca disparan |
| años para distinguir Sharpe 0.5 de 0.0 | **~31** |

## ⚠️ Los dos hallazgos que definen la sesión

**1 · Robustez no es significancia.** La estrategia es robusta a las dieciséis
decisiones que probamos —ninguna la mueve más de un error estándar— y al mismo
tiempo no tiene alfa demostrable (t = 1.83, Sharpe honesto 0.51). Las dieciséis
pruebas comparten los mismos datos: si la señal es un accidente del período, el
accidente sobrevive intacto a todas ellas.

**2 · El stop por drawdown habría apagado lo que funcionaba.** Las tres reglas
probadas (−5%, −10%, −15%) disparan en 2017-2018, y en los tres casos el Sharpe
posterior al disparo sigue siendo positivo. El stop al −10% dispara cuando el
Sharpe acumulado era 1.69, el mejor momento de toda la historia. Una estrategia
con Sharpe 1.0 y vol 15% tiene drawdowns del 10-20% **por construcción**: el
drawdown no tiene la información para distinguir "se rompió" de "le tocó un
mal año".

## Reproducirlo

```bash
python descargar_sec_edgar.py
python descargar_ibkr.py --que diario
```
