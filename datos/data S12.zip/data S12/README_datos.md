# Datos de la sesión 12

## `ibkr_diario.parquet`

**El mismo archivo de S7 a S11.** ✅ Dato real de Interactive Brokers. Ver
`S7_features/data S7/README_datos.md` para el detalle de procedencia.

| | |
|---|---|
| Filas | 82.895 · 33 símbolos · 7 sectores |
| Rango | 2016-10-17 → 2026-10-14 (2.512 días) |
| Frecuencia | Barras diarias, `useRTH=True` |

---

## ⚠️ El NaN de AVGO — y por qué este README lo documenta

Este archivo tiene **exactamente un valor ausente**: el cierre de **AVGO del
2018-04-05**. Uno, sobre 82.896 celdas: el **0.0012%** del dato.

En las sesiones 7 a 11 ese hueco era inofensivo. Las operaciones usadas ahí
(medias rodantes, rankings, pivots) lo propagan como NaN y desaparece sin
consecuencias.

**En la sesión 12 no.** El test de cointegración de Engle-Granger, al recibir
una serie con un hueco, degenera internamente: las series resultan casi
perfectamente colineales, el estadístico se va a −∞ y el p-valor interpolado
sale **exactamente 0.0**.

El resultado, medido en el notebook:

| | p = 0.0 exactos | p < 0.05 |
|---|---|---|
| AVGO contra los otros 32, **sin limpiar** | **32 de 32** | 32 |
| AVGO contra los otros 32, **con `dropna()`** | 0 | 2 |

**32 pares que habrían pasado cualquier corrección por multiple testing**,
incluido Bonferroni, y que habríamos presentado como los pares más cointegrados
del universo.

El único aviso era un `CollinearityWarning` de `statsmodels`, perdido entre
cientos de líneas de salida.

> 🔴 **Por eso el notebook abre con higiene de datos y no con estadística.** El
> bloque 2 reproduce el bug a propósito, lo mide, y deja la regla: *un p-valor
> exactamente 0.0 casi nunca es un hallazgo — es un bug.*

### Cómo lo maneja el notebook

```python
px = px_crudo.dropna()      # 2.511 días completos de 2.512
```

Se descarta **un día** del panel entero. Es la decisión correcta aquí porque
el análisis es cross-seccional entre pares y necesita series alineadas.

Para otros usos puede convenir interpolar o rellenar hacia adelante, pero
entonces hay que declararlo: rellenar un cierre inventa un precio que nunca
existió, y en un test de estacionariedad eso también sesga.

---

## La partición de la muestra

El notebook divide los 2.511 días en dos mitades exactas:

| | Período | Días | Para qué |
|---|---|---|---|
| **In-sample** | 2016-10-17 → 2021-10-12 | 1.255 | buscar pares y estimar β |
| **Out-of-sample** | 2021-10-13 → 2026-10-14 | 1.256 | operarlos |

**Nada de la segunda mitad se usa para decidir nada**: ni la selección de
pares, ni el hedge ratio β, ni los parámetros de las bandas. Es la disciplina
de S5 aplicada al pie de la letra, y es lo que hace interpretable el resultado
(Sharpe medio +0.445 dentro, +0.002 fuera).

---

## Qué hace el notebook con el dato

| Bloque | Cómputo |
|---|---|
| 2 · higiene | 64 tests de cointegración (32 sucios + 32 limpios) |
| 3 · screening | **528 tests** de Engle-Granger sobre la primera mitad |
| 4 · persistencia | 34 tests en la segunda mitad + 68 estimaciones de OU |
| 5 · estrategia | 34 backtests de pares × 5 niveles de costo = 170 corridas |

**Total: ~790 tests y backtests, en unos 20 segundos.**

## Reproducirlo

```bash
python descargar_ibkr.py --que diario
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
