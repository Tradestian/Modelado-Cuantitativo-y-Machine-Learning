# Datos de la sesión 11

## `ibkr_diario.parquet`

**El mismo archivo de S7 a S10.** ✅ Dato real de Interactive Brokers. Ver
`S7_features/data S7/README_datos.md` para el detalle de procedencia.

| | |
|---|---|
| Filas | 82.895 · 33 símbolos · 7 sectores |
| Rango | 2016-10-17 → 2026-10-14 (2.512 días) |
| Frecuencia | Barras diarias, `useRTH=True` |

## Por qué es deliberadamente el mismo dato y la misma estrategia que S10

Esta sesión **no compara estrategias: compara implementaciones.** Para que la
reconciliación tenga sentido, todo lo demás tiene que ser idéntico — mismos
precios, misma señal (momentum 60d, quintil superior, solo largo), mismo
período.

Si cambiáramos el dato o la estrategia, cualquier diferencia entre vectorbt y
el motor sería inatribuible. Así, cada diferencia tiene exactamente una causa
posible, y el notebook las nombra todas.

## Dependencia de software

```bash
pip install vectorbt
```

En Colab hay que instalarlo en la primera celda. El notebook comprueba la
importación y sigue funcionando si falta, pero los bloques 2, 3 y 4 quedan
vacíos.

Versión usada para generar las salidas: **vectorbt 1.0.0**.

> ⚠️ `vectorbt` cambia de API entre versiones mayores. Si las salidas no
> coinciden con las del notebook entregado, lo primero que hay que comprobar
> es la versión — y, de hecho, ése es un caso real del protocolo de
> reconciliación que enseña la sesión.

## Qué hace el notebook con el dato

| Bloque | Corridas |
|---|---|
| 2 · vectorbt | 1 backtest con vectorbt (0.14 s, 18.937 órdenes) |
| 3 · reconciliación | 2 de vectorbt + 2 vectorizados a mano |
| 4 · barrido | **420 backtests** en ~1 s |
| 4 · walk-forward | **480 backtests** (8 folds × 60 lookbacks) en ~2 s |
| 5 · prueba del slippage | 5 backtests con slippage creciente |

**Total: unos 910 backtests en menos de 15 segundos.** Con el motor de S10
serían unas 30 horas. Ésa es, literalmente, la lección del bloque 1.

## Reproducirlo

```bash
python descargar_ibkr.py --que diario
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
