# Datos de la sesión 15

**Los mismos dos archivos de S14**, a propósito: esta sesión continúa el
análisis exactamente donde quedó, y cualquier cambio de dato haría
inatribuibles las diferencias.

| Archivo | Qué es |
|---|---|
| `ibkr_diario.parquet` | 33 acciones × 10 años, OHLCV diario ajustado |
| `fundamentales_pit.parquet` | 48.776 observaciones de SEC EDGAR (tag canónico) con fecha de publicación |

Ver `S14_factor_timing_I/data S14/README_datos.md` para el detalle completo:
procedencia, tags alternativos, el caso del CIK de XOM y la regla
split/re-expresión.

## Lo que el notebook reconstruye

S15 **recalcula los siete factores desde cero** con la misma función
`panel_pit()` de S14. No hereda un archivo intermedio, y eso es deliberado:
el notebook es autónomo y verificable de punta a punta.

| Familia | Factores |
|---|---|
| Fundamentales (de S14) | ROE, ROA, caja/activos, earnings yield |
| Técnicos (de S7) | momentum 60d, reversión 5d, volatilidad 20d |

## Los números que produce

| Resultado | Valor |
|---|---|
| Correlación entre familias | **1 par de 21 supera \|ρ\| = 0.4** (ROE vs ROA, 0.70) |
| IC del mejor factor solo | 0.0643 (t = 2.86) |
| IC de los tres combinados | **0.0736 (t = 3.71)** |
| Sharpe con selección mirando todo | 1.019 ⚠️ |
| Sharpe con selección walk-forward | **0.511** ✅ |
| Beta al benchmark equiponderado | 0.363 |
| Alfa anual | +6.24% (t = 1.83) |
| IR predicho por Grinold (breadth nominal) | 0.866 |
| IR realizado | 0.581 |

## ⚠️ El hallazgo que define la sesión

**Elegir los tres factores mirando todo el período valía 0.51 de Sharpe —
la mitad del resultado.**

No es un error exótico: es mirar una tabla de estadísticos t y quedarse con
los tres más altos. El walk-forward muestra que en las primeras revisiones
se habrían elegido factores que después no funcionaron, y que el ganador
(volatilidad) solo se sabía ganador al final.

## Reproducirlo

```bash
python descargar_sec_edgar.py
python descargar_ibkr.py --que diario
```
