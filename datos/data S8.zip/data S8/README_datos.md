# Datos de la sesión 8

**Todo real, descargado de Interactive Brokers vía IB Gateway.** Esta sesión no
usa ningún dato simulado.

---

## `ibkr_diario.parquet`

El mismo archivo de S7. Ver `S7_features/data S7/README_datos.md` para el
detalle completo.

| | |
|---|---|
| Filas | 82.895 · 33 símbolos · 7 sectores |
| Rango | 2016-10-17 → 2026-10-14 (2.512 días) |
| Frecuencia | Barras diarias, `useRTH=True` |

**Para qué se usa aquí:** las dos ACF, la regresión de la asimetría
(82.113 observaciones), GARCH(1,1) y vol targeting.

---

## `ibkr_intradia_5min.parquet`

| | |
|---|---|
| **Filas** | 97.530 |
| **Símbolos** | 5 — AAPL, JPM, XOM, NEE, MCD |
| **Rango** | 2025-10-15 → 2026-10-14 (1 año, 251 días) |
| **Frecuencia** | Barras de 5 minutos |
| **Barras por día** | 78 (mediana), de 09:30 a 15:55 ET |
| **Zona horaria** | `US/Eastern`, con tz en la columna `date` |

### Columnas

Las mismas que el diario: `date, open, high, low, close, volume, average,
barCount, symbol, sector`.

### Para qué se usa

Calcular la **volatilidad realizada** diaria sumando los ~78 retornos de 5
minutos de cada día, y ajustar el modelo **HAR-RV** de Corsi (2009).

### ⚠️ La limitación, declarada

IBKR no entrega más de ~1 año de historia de barras de 5 minutos. Eso deja
**229 observaciones utilizables de volatilidad realizada por símbolo** después
de los rezagos de 22 días.

Es poco. El notebook lo dice explícitamente y lo maneja de dos formas:

1. **Agrupa los 5 símbolos** en un solo panel (1.145 observaciones) para
   estimar el HAR-RV con algo de poder estadístico.
2. **La magnitud sólida se mide en el panel diario de 10 años**, donde la misma
   regresión sobre `|r|` da R² = 0.1797 con 82.113 observaciones.

El bloque de HAR-RV demuestra el **método**; el número en el que confiar está
en el bloque 1.

### Por qué 5 símbolos y no 33

El intradía pesa mucho más por símbolo, y el pacing de IBKR (11 s entre
peticiones) lo hace lento. Cinco nombres líquidos de sectores bien distintos
alcanzan para la demo. Si hiciera falta más, el script los soporta: basta
editar la lista `INTRADIA` en `descargar_ibkr.py`.

---

## Verificación hecha

| Chequeo | Resultado |
|---|---|
| Nulos | 0 |
| Barras fuera de sesión regular (antes de 09:30, después de 16:00) | 0 |
| Días con menos de 78 barras | pocos, y son medias sesiones reales (festivos) |
| Días de RV igual a cero | 0 (se filtran por si acaso) |

---

## Reproducirlo

```bash
python descargar_ibkr.py --que diario
python descargar_ibkr.py --que intradia
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
