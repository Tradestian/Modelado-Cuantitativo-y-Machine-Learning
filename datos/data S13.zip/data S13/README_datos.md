# Datos de la sesión 13

## `ibkr_diario.parquet`

**El mismo archivo de S7 a S12.** ✅ Dato real de Interactive Brokers. Ver
`S7_features/data S7/README_datos.md` para el detalle de procedencia.

| | |
|---|---|
| Filas | 82.895 · 33 símbolos · 7 sectores |
| Rango | 2016-10-17 → 2026-10-14 (2.512 días; 2.511 tras `dropna`) |
| Frecuencia | Barras diarias, `useRTH=True` |

## Por qué es deliberadamente el mismo dato que S12

Esta sesión contesta cuatro objeciones a la estrategia de S12. **Para que las
respuestas sean atribuibles, todo lo demás tiene que ser idéntico**: mismos
precios, mismo período, mismo screening de pares.

El notebook lo verifica en vivo: recalcula los 528 tests de cointegración y
obtiene los mismos 34 pares. Si cambiáramos el dato, cualquier diferencia
entre S12 y S13 sería inatribuible.

## Lo que el notebook calcula

| Bloque | Cómputo |
|---|---|
| 1 | 528 tests de Engle-Granger |
| 3 | 68 backtests (34 pares × β fijo y rodante) |
| 4 | 272 backtests (8 reglas × 34 pares) + 170 del filtro de half-life |
| 5 | **4.352 backtests** (2 mallas × 64 configuraciones × 34 pares) |

**Total: ~4.900 backtests en unos 65 segundos.**

> 📌 Eso es posible porque la máquina de estados de la estrategia está escrita
> en **numpy puro** en vez de iterar sobre un `pd.Series`. La diferencia
> medida es de **20×**. En pandas, el bloque 5 solo tardaría más de un minuto
> y la sesión entera varios.
>
> No es una optimización cosmética: si el barrido fuera lento, no habríamos
> probado 64 configuraciones — y no habríamos encontrado el bug que es el
> centro del bloque 5.

## El valor ausente de AVGO

El panel tiene un nulo (AVGO, 2018-04-05). El notebook aplica `dropna()` sobre
el panel completo, igual que S12, lo que descarta ese día para todos los
símbolos. Quedan 2.511 días.

Es la decisión correcta acá porque el análisis es por pares y necesita series
alineadas. En S12 ese mismo hueco, sin limpiar, producía 32 pares con p-valor
exactamente 0.0.

## Reproducirlo

```bash
python descargar_ibkr.py --que diario
```

Requiere IB Gateway abierto en el puerto 4002 con la API habilitada.
