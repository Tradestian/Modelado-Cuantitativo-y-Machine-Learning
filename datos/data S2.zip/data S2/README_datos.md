# Procedencia de los datos — Sesión 2

Esta sesión usa **datos reales y gemelos simulados**, y la distinción es
parte del contenido, no un detalle técnico.

## Datos REALES

### `equities_reales_diario.parquet`
9 tickers, uno por sector, de tu carpeta `Trading Labs/data/ohlcv`. Velas de
5 minutos **filtradas a sesión regular (09:30–15:55)** y resampleadas a
diario.

> ⚠️ El filtro de sesión regular es importante: cinco de los nueve archivos de
> origen incluyen horario extendido (04:00–19:55) y cuatro no. Sin filtrar,
> el dólar-volumen queda inflado hasta 2x para unos tickers y no para otros,
> y el rango high-low se ensancha artificialmente — lo que rompe por completo
> el estimador de Corwin-Schultz del bloque 4.

### `trades_reales_btcusd.parquet`
300 operaciones tick-by-tick reales, BTC-USD.
- **Fuente:** Coinbase Exchange, API pública, `GET /products/BTC-USD/trades`
- **Capturado:** 21 de agosto de 2026
- **Rango:** ~33 segundos de mercado real

### `order_book_real_xbtusd.parquet`
Libro de órdenes real, 20 niveles por lado.
- **Fuente:** Kraken, API pública, `GET /0/public/Depth?pair=XBTUSD&count=20`
- **Capturado:** 25 de agosto de 2026
- **Uso en S2:** provee el **spread verdaderamente observado** (0.013 bps)
  contra el cual contrastamos la estimación de Roll.

## Gemelos SIMULADOS (con verdad conocida)

Generados con `curso_data.py` (mismo generador que usan tus notebooks de
estudio). La verdad de cada uno está en `verdad_gemelos.json`.

### `trades_gemelo_simulado.parquet`
20.000 trades con **spread verdadero = 6.0 bps**, elegido por nosotros.

**Para qué:** verificar que la implementación del estimador de Roll es
correcta, y medir cuántos trades necesita para converger. Con datos reales
esto es imposible — no existe un archivo con "el spread verdadero".

### `equities_gemelo_simulado.parquet`
10 tickers sintéticos con **spread verdadero por tier**: LIQUID = 3 bps,
MID = 12 bps, ILLIQUID = 45 bps.

**Para qué:** demostrar que Corwin-Schultz sobreestima el spread ~4.5x y
correlaciona más con la volatilidad (rho +0.78) que con el spread que dice
medir (rho +0.71). Esa conclusión **solo es demostrable** teniendo la verdad
al lado.

## El criterio, en una frase

> Los datos reales muestran **cómo se comporta el mundo**.
> Los gemelos simulados muestran **si nuestras herramientas sirven**.

Un estimador puede estar correctamente implementado y aun así darte un número
equivocado, porque sus supuestos no se cumplen en tus datos. Para separar
"el código está mal" de "el supuesto no aplica" hacen falta los dos.
